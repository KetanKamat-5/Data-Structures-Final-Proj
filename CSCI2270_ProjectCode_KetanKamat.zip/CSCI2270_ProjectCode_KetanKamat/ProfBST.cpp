//-----------------------------------------------------------------------------
// CSCI2270 Course Project
// Author: Ketan Kamat
// Date of Submission: 12/6/2021
// Identification: ProfBST.cpp
//-----------------------------------------------------------------------------

#include "ProfBST.h"

#include <iostream>

using namespace std;

// Constructor:
ProfBST::ProfBST()
{
// Set root to null
root = NULL;
}

//Destructor Helper Function:
//input: Address of specific node
//output: void
void destruct_helper(Professor* root) {
// Check if root is null
if (root!=NULL) {
// If the left node is not empty, then delete it

if (root->left !=NULL) {
destruct_helper(root->left); // recursion
}

// If the right node is not empty, then delete it
if (root->right !=NULL) {
destruct_helper(root->right); //recursion
}

delete root; // delete the specific node
}

}

//Destructor:
ProfBST::~ProfBST()
{
destruct_helper(root);
}

//addProfessor:
//input: profId (id of professor), profName (name of professor)
//output: void
void ProfBST::addProfessor(string profId, string profName)
{

// Temporary assignment to root and construction of Professor class
Professor* temp = root;
Professor* newProf = new Professor(profId, profName);

// If the root is null then create it
if (root == NULL) {
root = newProf; 
return;
}

// Traversing the tree
while (temp != NULL) {

// If duplicate key is found
if (profId.compare(temp->profId) == 0) {
cout << "Error: duplicate key" << endl;
return;
}

// Look left
else if (profId.compare(temp->profId) < 0) {  
if (temp->left == NULL) {
//insertion
temp->left = newProf;
return;
}
// Look left again
temp = temp->left;
}

//Look Right
else { 
if (temp->right == NULL) {
//insertion
temp->right = newProf;
return;
}
// Look right again
temp = temp->right;
}

}

}

//searchProfessor:
//input: profId (id of professor)
//output: Professor pointers
Professor* ProfBST::searchProfessor(string profId)
{
// Assign temp to the root of tree to begin searching
Professor* temp = root;
// While the specific node is not null keep searching
while (temp != NULL) {
// If the id has been found
if (profId.compare(temp->profId) == 0) {
return temp;
}
// If the id is smaller than the current node id then look left
if (profId.compare(temp->profId) < 0) {
temp = temp->left;
}
// If the id is larger than the current node id then look left
else {
temp = temp->right;
}
}
//didn't find it return null
return NULL;
}

//publicSearchProfessor:
//input: profId (id of professor)
//output: void
void ProfBST::publicSearchProfessor(string profId)
{
// Assign temp to the root of the tree to begin search
Professor* temp = root;
// While the specific node is not null keep searching
while (temp != NULL) {
if (profId.compare(temp->profId) == 0) {
//found the node
}
//profid is smaller than nodeid, then look left
if (profId.compare(temp->profId) < 0) {
temp = temp->left;
}
//profid is larger than node id, then look right
else {
temp = temp->right;
}
}
}

//displayProfessorInfo:
//input: p (pointer to node)
//output: void
void ProfBST::displayProfessorInfo(Professor* p)
{
// Print info:
cout<<p->profName<<endl;
for (int a=0;a<p->coursesTaught.size();a++) {
cout<<"- ";
cout<<p->coursesTaught.at(a)->courseNum;
cout<<" ";
cout<<p->coursesTaught.at(a)->courseName;
cout<<" ";
cout<<p->coursesTaught.at(a)->year;
cout<<" ";
cout<<endl;
}
}

