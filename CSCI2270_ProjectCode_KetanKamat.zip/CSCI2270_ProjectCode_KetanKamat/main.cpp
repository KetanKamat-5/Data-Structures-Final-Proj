//-----------------------------------------------------------------------------
// CSCI2270 Course Project
// Author: Ketan Kamat
// Date of Submission: Dec 6th 2021
// Identification: main.cpp
//-----------------------------------------------------------------------------

#include "HashOpenAddressing.h"
#include "HashChaining.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

int main (int argc, char* argv[])
{
//Ensure that the right number of command line arguments are entered:
if (argc!=3) {
cout<<"Invalid number of arguments."<<endl;
cout<<"Usage: ./<program name> <csv file> <hashTable size"<<endl;
}

//Initialize:
int option = -1; //Initialize option
HashOpenAddressing h_o(stoi(argv[2]));
ProfBST prof;
HashChaining h_c(stoi(argv[2]));


// Printing Menu and Option Insert:
while (option!=5) {
cout<<"=======Main Menu======="<<endl;
cout<<"1. Populate hash tables"<<endl;
cout<<"2. Search for a course"<<endl;
cout<<"3. Search for a professor"<<endl;
cout<<"4. Display all courses"<<endl;
cout<<"5. Exit"<<endl;
cin>>option;

//Option 1:
 if (option==1) {
// Calling the bulk insert function for chaining and open addressing
 h_o.bulkInsert(argv[1]);
h_c.bulkInsert(argv[1]);
}

//Option 2:
else if (option ==2) {
int course_year;
int course_number;
string Professor_Id;
cout<<"Enter the course year (e.g. 2021):"<<endl;
cin>>course_year;
cout<<"Enter a course number (e.g. 2270):"<<endl;
cin>>course_number;
cout<<"Enter a Professor's ID (e.g. llytellf):"<<endl;
cin>>Professor_Id;
 h_o.search(course_year,course_number,Professor_Id);
h_c.search(course_year,course_number,Professor_Id);
 }

 //Option 3:
else if (option ==3) {
cout<<"Please enter the professor ID"<<endl;
string profId;
cin>>profId;
Professor* location = h_o.profDb.searchProfessor(profId);
Professor* location2 = h_c.profDb.searchProfessor(profId);
if (location==NULL) {
cout<<"Professor could not be found"<<endl;
}
else {
cout<<"[OPEN ADDRESSING] displayCourseInfo()"<<endl;
cout<<"--------------------------------"<<endl;
h_o.profDb.displayProfessorInfo(location);
cout<<"[CHAINING] Hash table populated"<<endl;
cout<<"--------------------------------------------------------"<<endl;
h_c.profDb.displayProfessorInfo(location2);
}
}

//Option 4:
else if (option ==4) {
string option;
cout<<"Which hash table would you like to display the courses for (O=Open Addressing, C=Chaining)?"<<endl; 
cin>>option;
if (option=="O") {
h_o.displayAllCourses();
}
else {
h_c.displayAllCourses();
}
}

}
//Exit
return 0;
}