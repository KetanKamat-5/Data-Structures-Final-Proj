//-----------------------------------------------------------------------------
// CSCI2270 Course Project
// Author: Ketan Kamat
// Date of Submission: 12/6/2021
// Identification: HashOpenAddressing.cpp
//-----------------------------------------------------------------------------

#include "HashOpenAddressing.h"
#include<cstring>
#include<cmath>
using namespace std;

//Constructor:
//input: size (number of lines in file)
HashOpenAddressing::HashOpenAddressing(int size)
{
	hashTableSize = size;
	hashTable = new Course * [hashTableSize];
	for (int i = 0; i < hashTableSize; i++) {
		hashTable[i] = NULL;
	}
}

//Destructor:
HashOpenAddressing::~HashOpenAddressing()
{
// Iterating through the hashtable until all the indices have been deleted
for (int deletor = 0;deletor<hashTableSize;deletor++) {
if (hashTable[deletor]!=NULL) {
delete hashTable[deletor];
}
}
}

//hash:
//input: Address of specific node
//output: void
int HashOpenAddressing::hash(int courseNumber)
{
// Return hash value:
int index = courseNumber % hashTableSize;
return index;
}


//bulkInsert:
//input: name of file
//output: void
void HashOpenAddressing::bulkInsert(string filename)
{
int searchops_open = 0;
int collision_open = 0;
// Reading in the lines
ifstream fileopener_a;
string line;
fileopener_a.open(filename);
// skip first line
bool firstTime = true;

//Read in lines:
while(getline(fileopener_a,line)) 
{
if (firstTime) {
firstTime = false;
			}
else {
string year, department, course_num, course_name, prof_id, prof_fname, prof_lname;
stringstream  ss(line);
getline(ss, year, ',');
getline(ss, department, ',');
getline(ss, course_num, ',');
getline(ss, course_name, ',');
getline(ss, prof_id, ',');
getline(ss, prof_fname, ',');
getline(ss, prof_lname, ',');
int index = hash(stoi(course_num));
// Call Probing Function:
int i = 0;
// Counting collisions:
if (hashTable[index]!=NULL) {
collision_open++;
}
// Adding courses
while (hashTable[index]!= NULL) {
i++;
index = (index+pow(i,2));
index = (index) % (hashTableSize);
}
searchops_open+=i;
hashTable[index] = new Course;
hashTable[index]->courseName = course_name;
hashTable[index]->courseNum = stoi(course_num);
hashTable[index]->department = department;
hashTable[index]->next = NULL;
hashTable[index]->previous = NULL;
hashTable[index]->year = stoi(year);

// Adding professors, if the professor has been found
string prof_name = prof_fname+" "+prof_lname;
Professor * location = profDb.searchProfessor(prof_id);

// Case 1: Prof needs to be added
if (location==NULL) {
profDb.addProfessor(prof_id,prof_name);
location = profDb.searchProfessor(prof_id);
hashTable[index]->prof = location;
location->coursesTaught.push_back(hashTable[index]);
}
// Case 2: Appending data
else {
hashTable[index]->prof = location;
hashTable[index]->prof->coursesTaught.push_back(hashTable[index]);
}
}
}
//Printing:
cout<<"[OPEN ADDRESSING] Hash table populated"<<endl;
cout<<"--------------------------------------------------------"<<endl;
cout<<"Collisions using open addressing: "<<collision_open<<endl;
cout<<"Search operations using open addressing:"<<searchops_open<<endl;
fileopener_a.close(); // close source
}

//search:
//input: courseYear (year course was run),courseNumber (course Id), profID (id of professor)
//output: void
void HashOpenAddressing::search(int courseYear, int courseNumber, string profId)
{
int search_ops_so= 0; //search operations
for (int iterator=0;iterator<hashTableSize;iterator++) {
if (hashTable[iterator]!=NULL) {
if (hashTable[iterator]->courseNum == courseNumber && hashTable[iterator]->year == courseYear)
{
search_ops_so++; //Only if certain parameters match do you add to search operations
if (hashTable[iterator]->prof->profId == profId) { //Final condition, match found
// Printing
cout<<"[OPEN ADDRESSING] Search for a course"<<endl;
cout<<"-------------------------------------"<<endl;
cout<<"Search operations using open addressing: "<<search_ops_so<<endl;
cout<<hashTable[iterator]->year;
cout<<" ";
cout<<hashTable[iterator]->courseName;
cout<<" ";
cout<<hashTable[iterator]->courseNum;
cout<<" ";
cout<<hashTable[iterator]->prof->profName;
cout<<endl;
break; //Break loop
}
}
}
}
}

//displayAllCourses:
//input: void
void HashOpenAddressing::displayAllCourses()
{
// Print
cout<<"[OPEN ADDRESSING] displayAllCourses()"<<endl;
cout<<"--------------------------------"<<endl;
for (int iterator=0;iterator<hashTableSize;iterator++) { 
// Print info
if (hashTable[iterator]!=NULL) {
cout<<"2";
cout<<hashTable[iterator]->year;
cout<<" ";
cout<<hashTable[iterator]->courseName;
cout<<" ";
cout<<hashTable[iterator]->courseNum;
cout<<" ";
cout<<hashTable[iterator]->prof->profName;
cout<<" ";
cout<<endl;
}
}
}

//displayCourseInfo:
//input: c (address of course)
//output: void
void HashOpenAddressing::displayCourseInfo(Course* c)
{
// Print info
cout<<"[OPEN ADDRESSING] displayCourseInfo()"<<endl;
cout<<"--------------------------------"<<endl;
cout<<c->year;
cout<<" ";
cout<<c->courseName;
cout<<" ";
cout<<c->courseNum;
cout<<" ";
cout<<c->prof->profName;
cout<<endl;
}