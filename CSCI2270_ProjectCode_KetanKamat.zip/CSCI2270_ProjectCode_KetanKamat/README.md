<img src="https://www.colorado.edu/cs/profiles/express/themes/ucb/images/cu-boulder-logo-text-black.svg" alt="CU Boulder Logo" width="500">

# CSCI 2270: Data Structures <br/> University Courses Database Project

# Author: Ketan Kamat
# Date of Submission: 12/6/2021

This was my final project for CSCI 2270 (Data Structures and Algorithms). The objective of the project was to organize/place the contents of  abritary file containing a list of courses and associated parameters (e.g. professors,coursenumber) into a hashtable and BST using quadratic probing and chaining.

My code perfectly matched the expected output of the test cases provided in an appropriate time frame.