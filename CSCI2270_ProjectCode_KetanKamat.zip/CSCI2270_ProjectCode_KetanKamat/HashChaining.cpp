//-----------------------------------------------------------------------------
// CSCI2270 Course Project
// Author: Ketan Kamat
// Identification: HashChaining.cpp
//-----------------------------------------------------------------------------

#include "HashChaining.h"

using namespace std;

//Constructor:
//input: size
HashChaining::HashChaining(int size)
{
hashTableSize = size; // declare hashtable size
hashTable = new Course * [hashTableSize]; 
// iterate through hashtable and ensure components are null
for (int i = 0; i < hashTableSize; i++) {
	hashTable[i] = NULL;
}
}

//Destructor:
HashChaining::~HashChaining()
{
// Iterate through hashtable and delete all buckets
for (int i = 0; i < hashTableSize; i++) {
		if (hashTable[i] != NULL) {
		Course* head = hashTable[i];
			while (head!=NULL) {
			Course* temp = head;
			head = head->next;
			delete temp;
			}
		}
	}
}

//hash:
//input: courseNumber
//output: hashvalue
int HashChaining::hash(int courseNumber)
{
int hashvalue = courseNumber % hashTableSize;
return hashvalue;
}

//bulkInsert:
//input: filename
//output: void
void HashChaining::bulkInsert(string filename)
{
//Reading in file and setting variables to zero
ifstream fileopener_a;
string line;
int searchops_chain = 0;
int collision_chain = 0;
fileopener_a.open(filename);
if (fileopener_a.is_open()) {
bool firstTime = true;
while (getline(fileopener_a, line)) {
if (firstTime) {
firstTime = false;
}
else {
//split cols of data
string year, department, course_num, course_name, prof_id, prof_fname, prof_lname;

stringstream  ss(line);
getline(ss, year, ',');
getline(ss, department, ',');
getline(ss, course_num, ',');
getline(ss, course_name, ',');
getline(ss, prof_id, ',');
getline(ss, prof_fname, ',');
getline(ss, prof_lname, ',');
int index = hash(stoi(course_num));

//Case 1:
if (hashTable[index] == NULL) {
Course* newCourse = new Course;
hashTable[index] = newCourse;
hashTable[index]->courseName = course_name;
hashTable[index]->courseNum = stoi(course_num);
hashTable[index]->department = department;
hashTable[index]->next = NULL;
hashTable[index]->previous = NULL;
hashTable[index]->year = stoi(year);
// Adding professors, if the professor has been found
string prof_name = prof_fname+" "+prof_lname;
Professor * location = profDb.searchProfessor(prof_id);

if (location==NULL) {
profDb.addProfessor(prof_id,prof_name);
location = profDb.searchProfessor(prof_id);
hashTable[index]->prof = location;
location->coursesTaught.push_back(hashTable[index]);
}

else {
hashTable[index]->prof = location;
hashTable[index]->prof->coursesTaught.push_back(hashTable[index]);
}

}


// Case 2:
else {
collision_chain++;
Course* head = hashTable[index];
while (head->next!=NULL) {
searchops_chain++;
head = head->next;
}
searchops_chain++;
Course* newCourse = new Course;
head->next = newCourse;
newCourse->previous = head;
newCourse->courseName = course_name;
newCourse->courseNum = stoi(course_num);
newCourse->department = department;
newCourse->next = NULL;
newCourse->year = stoi(year);

// Insert professor
// Adding professors, if the professor has been found
string prof_name = prof_fname+" "+prof_lname;
Professor * location = profDb.searchProfessor(prof_id);

if (location==NULL) {
profDb.addProfessor(prof_id,prof_name);
location = profDb.searchProfessor(prof_id);
newCourse->prof = location;
location->coursesTaught.push_back(newCourse);
}

else {
newCourse->prof = location;
newCourse->prof->coursesTaught.push_back(newCourse);
}
}

}
}
}
cout<<"[CHAINING] Hash table populated"<<endl;
cout<<"--------------------------------------------------------"<<endl;
cout<<"Collisions using chaining: "<<collision_chain<<endl;
cout<<"Search operations using chaining: "<<searchops_chain<<endl;
}

//search:
//input: courseYear,courseNumber,profId
//output: void
void HashChaining::search(int courseYear, int courseNumber, string profId)
{
 // Index
int index = courseNumber % hashTableSize;
Course* head = hashTable[index];
// Preset search ops
int search_ops_sc = 0;
while (head!=NULL) {
if (head->year == courseYear && head->courseNum == courseNumber && head->prof->profId == profId) { //Found case
// Print
cout<<"[CHAINING] Search for a course"<<endl;
cout<<"-------------------------------------"<<endl;
cout<<"Search operations using chaining: "<<search_ops_sc<<endl;
cout<<head->year;
cout<<" ";
cout<<head->courseName;
cout<<" ";
cout<<head->courseNum;
cout<<" ";
cout<<head->prof->profId;
cout<<" ";
cout<<endl;
}
head = head->next; //Move to next node
search_ops_sc++; //Increment
}
}

//displayAllCourses
//output: void
void HashChaining::displayAllCourses()
{
int iterator = 0;
// Display all courses
cout<<"[CHAINING] displayAllCourses()"<<endl;
cout<<"--------------------------------"<<endl;
for (int iterator=0;iterator<hashTableSize;iterator++) { //Iterate
if (hashTable[iterator]!=NULL) {
Course* loop = hashTable[iterator];
while (loop!=NULL) {
cout<<"2";
cout<<loop->year;
cout<<" ";
cout<<loop->courseName;
cout<<" ";
cout<<loop->courseNum;
cout<<" ";
cout<<loop->prof->profName;
cout<<" ";
cout<<endl;
loop = loop->next;
}
}
}
}

//displayCourseInfo
//input: c (pointer to course)
//output: void
void HashChaining::displayCourseInfo(Course* c)
{
// Print info
cout<<"[CHAINING] displayCourseInfo()"<<endl;
cout<<"--------------------------------"<<endl;
cout<<"2"<<c->year;
cout<<" ";
cout<<c->courseName;
cout<<" ";
cout<<c->courseNum;
cout<<" ";
cout<<c->prof->profName;
cout<<endl;
}